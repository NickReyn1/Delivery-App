class location:
    def __init__(self, locationID, locationName, locationAddress, locationZip):
        self.locationID = locationID
        self.locationName = locationName
        self.locationAddress = locationAddress
        self.locationZip = locationZip

